import java.awt.*;
import java.util.*;

public class Krawedzie {
	
	int n;
	ArrayList<Edge> tab = new ArrayList<>();
	
	public void paintComponent(Graphics g, Canvas canvas, Graf V) {
		for(Edge e: tab) {
			e.paintComponent(g, canvas, V);
		}
	}
	
	public void readE(Scanner sc, Graf V) {
		n = sc.nextInt();
		for(int i=0; i<n; i++) {
			int u = sc.nextInt();
			int v = sc.nextInt();
			tab.add(new Edge(u, v));
			V.pts.get(u).add_neigh(v);
			V.pts.get(v).add_neigh(u);
		}
	}
	
}
