import java.util.*;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.*;

public class Canvas extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D)g;
														//tlo
        g2d.setColor(Color.white);
		g2d.fillRect(0, 0, getWidth(), getHeight());
														//translacja i elementy
        g2d.translate(500, 350);
		g2d.setColor(Color.black);
		
		V.paintComponent(g, this);
		E.paintComponent(g, this, V);
	}
	
	Graf V = new Graf();
	Krawedzie E = new Krawedzie();
	TreeDfs tree = null;
	
	public Canvas() {
		
		Scanner in = null;
		try {
			in = new Scanner(new File("src/wejscie.in6"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		}
		V.readPts( in );				//n a potem ewentualnie x i y
		E.readE( in, V );				//m a potem u i v
		in.close();
		
										//uncomment to get a tree view
		//tree = new TreeDfs(V, 0);
		//tree.setcoordinates(V, 400, 400);
	}

}
