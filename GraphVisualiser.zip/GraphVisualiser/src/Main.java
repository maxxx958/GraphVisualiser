import javax.swing.JFrame;

public class Main {
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("GraphVis");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Canvas canvas = new Canvas();
		frame.add(canvas);
		frame.setSize(1000, 700);
		frame.setVisible(true);
	}
	
}
