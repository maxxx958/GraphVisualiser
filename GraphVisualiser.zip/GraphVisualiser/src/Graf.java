import java.awt.*;
import java.util.*;

public class Graf {
	
	public ArrayList<Point> pts = new ArrayList<>();
	int n;
	
	public void paintComponent(Graphics g, Canvas canvas) {
		for(Point p : pts) {
			p.paintComponent(g, canvas);
		}
	}
	
	public void readPts( Scanner in ) {
		n = in.nextInt();
		for(int i=0; i<n; i++) {
			//int px = sc.nextInt();		do debugowania
			//int py = sc.nextInt();		do debugowania
			pts.add(new Point(i, this));
		}
	}
	
}
