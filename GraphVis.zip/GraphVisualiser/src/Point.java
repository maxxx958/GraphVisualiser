import java.awt.Graphics;
import java.util.*;

public class Point {
	
	private int x;
	private int y;
	private int size = 10;
	
	public Point(int _x, int _y) {
		x=_x;
		y=_y;
	}
	
	//Getters
	public int getx() {
		return x;
	}
	public int gety() {
		return y;
	}
	
	//Setters
	public void setx( int val ) {
		this.x = val;
	}
	public void sety( int val ) {
		this.y = val;
	}
	public void setsize( int val ) {
		this.size = val;
	}
	
	
	public void paintComponent(Graphics g) {
		g.fillOval(x-size/2, y-size/2, size, size);
	}
	
}
