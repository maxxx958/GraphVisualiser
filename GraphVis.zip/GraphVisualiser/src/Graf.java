import java.awt.Graphics;
import java.util.*;

public class Graf {
	
	static ArrayList<Point> pts = new ArrayList<>();
	static int n;
	
	public static void paintComponent(Graphics g) {
		for(Point p : pts) {
			p.paintComponent(g);
		}
	}
	
	public static void readPts( Scanner sc ) {
		n = sc.nextInt();
		for(int i=0; i<n; i++) {
			int px = sc.nextInt();
			int py = sc.nextInt();
			pts.add(new Point(px, py));
		}
	}
	
}
