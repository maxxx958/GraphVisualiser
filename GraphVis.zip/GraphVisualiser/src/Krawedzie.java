import java.awt.Graphics;
import java.util.*;

public class Krawedzie {
	
	static int n;
	static ArrayList<Edge> E = new ArrayList<>();
	
	public static void paintComponent(Graphics g) {
		for(Edge e: E) {
			e.paintComponent(g);
		}
	}
	
	public static void readE(Scanner sc) {
		n = sc.nextInt();
		for(int i=0; i<n; i++) {
			int u = sc.nextInt();
			int v = sc.nextInt();
			E.add(new Edge(u, v));
		}
	}
	
}
