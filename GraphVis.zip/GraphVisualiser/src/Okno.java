import java.util.*;
import java.awt.*;
import javax.swing.*;

public class Okno extends JPanel{

	public void paintComponent(Graphics g) {
		g.setColor(Color.white);
		g.fillRect(0, 0, getWidth(), getHeight());
		g.setColor(Color.black);
		
		Graf.paintComponent(g);
		Krawedzie.paintComponent(g);
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Graf.readPts( sc );			//n a potem x i y
		Krawedzie.readE( sc );		//m a potem u i v
		
		JFrame frame = new JFrame("GraphVis");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Okno canvas = new Okno();
		
		frame.add(canvas);
		
		frame.setSize(600, 400);
		frame.setVisible(true);
		
		sc.close();
	}

}
