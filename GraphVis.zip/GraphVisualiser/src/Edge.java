import java.awt.Graphics;
import java.util.*;

public class Edge {
	
	private int u;
	private int v;
	Edge(int _u, int _v){
		u=_u;
		v=_v;
	}
	
	public void paintComponent(Graphics g) {
		g.drawLine(Graf.pts.get(u).getx(), Graf.pts.get(u).gety(), Graf.pts.get(v).getx(), Graf.pts.get(v).gety());
	}
	
}
